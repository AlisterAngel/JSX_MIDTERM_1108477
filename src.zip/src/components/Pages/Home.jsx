import Header from '../shared/Header.jsx';
import Instructions from '../shared/Instructions.jsx';
const Home = () => {

    return (
        <>
            <div className="container-fluid">
                <Header title="Home Sweet Home"/>
            </div>
            <Instructions/>
        </>
    );
}

export default Home;